# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: ap-cdbr-azure-southeast-b.cloudapp.net (MySQL 5.5.45-log)
# Database: acsm_6f40e825d2a18e3
# Generation Time: 2016-12-18 11:11:27 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table yaowarat_review
# ------------------------------------------------------------

DROP TABLE IF EXISTS `yaowarat_review`;

CREATE TABLE `yaowarat_review` (
  `review_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `review_name` varchar(255) DEFAULT NULL,
  `review_price` varchar(50) DEFAULT NULL,
  `review_opent` varchar(50) DEFAULT NULL,
  `review_location` varchar(255) DEFAULT NULL,
  `review` text,
  `review_img` text,
  PRIMARY KEY (`review_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `yaowarat_review` WRITE;
/*!40000 ALTER TABLE `yaowarat_review` DISABLE KEYS */;

INSERT INTO `yaowarat_review` (`review_id`, `review_name`, `review_price`, `review_opent`, `review_location`, `review`, `review_img`)
VALUES
	(271,'ฮั่วเซ่งฮง เยาวราช','100 ขึ้นไป','ทุกวัน : 10:00 - 23:59','ซอย เจริญกรุง (ข้างห้างทองเลี่ยมเซ่งเฮง ปากซอยเจริญกรุง14) ','มี “หูฉลาม” แผ่นใหญ่ๆ เนื้อกรุบๆ เป็นเมนูขึ้นชื่อที่ต้องมากินให้ได้ ','1481747803-1378473946-DSCF6395JP-o.jpg'),
	(281,'ขนมปังเจ้าอร่อยเด็ดเยาวราช เยาวราช','ชิ้นละ 25 บาท','อ. - อา. : 19:00 - 23:30','ถนน ผดุงด้าว (ใกล้กับร้านเซี้ยหูฉลาม ตรงข้ามโรงแรมบรอดเวย์)','ขนมปังกรอบนอกนุ่มใน ร้านเปิดมานานและคนแน่นจนต้องมีบัตรคิวรอ ขนมปังของร้านก็เด็ดสมชื่อ','1481747992-pungpung.jpg'),
	(291,'Sweet Time สัมพันธวงศ์','ธรรมดา 40-100','อ. - อา. : 18:00 - 02:00','ถนน เยาวราช (ติดร้านขายทุเรียนฮ่องกง)','ขนมหวานร้านดังแห่งเยาวราชที่ไปทีไรคนแน่นเสมอ เมนูของหวานของที่นี่มีให้เลือกหลากหลาย ทั้งแบบร้อนและแบบเย็น','1481748172-omg-011.jpg'),
	(301,'ครัวพรละมัย','50-100 บาท','อ. - อา. : 18:00 - 02:00','ถนนแปลงนาม เข้าซอยมานิดเดียว','เมนูเส้นเหนียวนุ่มคั่วในกระทะร้อน ๆ กลิ่นหอมเย้ายวนใจ','1481748561-omg-022.jpg'),
	(311,'ภัตตาคาร ตั้งจั้วหลี','150 บาทขึ้นไป','ทุกวัน 11.00 - 22.00 น.','ถนนข้าวหลาม (ติดกับ ธนาคาร UOB)','เมนูหัวปลาหม้อไฟ ที่มีเนื้อปลาสดอร่อยมาต้มกับเผือกในน้ำซุปรสชาติกลมกล่อม และ ฮื่อแซ(ปลาดิบ) ของขึ้นชื่อของทางร้านที่ทานคู่กับน้ำจิ้มรสเด็ด','1481748775-LUM_1447_Cover-620x392.jpg'),
	(321,'ป้าจิน หอยแครงลวก ซอยเท็กซัส ','80 บาทขึ้นไป','อ. - ส. : 18:30-23:59 อา. :17:00-23:59','ถนนผดุงด้าว (ซอยเท็กซัส)','ฟาดหอยแครงลวกไม่เหม็นคาวสดให้สะใจ เลือกระดับความสุกได้ มาพร้อมกับน้ำจิ้มถั่วรสเด็ด','1481748963-omg-033.jpg'),
	(331,'ก๋วยเตี๋ยวคั่วไก่กระทะทองเหลือง เยาวราช','ธรรมดา 30 พิเศษ 50','ทุกวัน : 06:00 - 12:00','ปากซอยตลาดเก่าเยาวราช เล่งบ๊วยเอี๊ยง','เมนูกระทะร้อนไฟแรงเฟร่อของร้านนี้เป็น “คั่วไก่” ความพิถีพิถันเหมาะสำหรับคนชอบทานคั่วไก่ที่ไก้กลิ่นไหม้ของกระทะ ','1481749147-5.jpg'),
	(341,'ก๋วยจั๊บนายเอ็ก','60-80 บาท','ทุกวัน 11.00 - 22.00 น.','ปากซอยเยาวราช 9 อยู่ด้านซ้ายมือ ของถนน','ขึ้นชื่อเรื่องความเข้มข้นกลมกล่อมและความเผ็ดร้อนของพริกไทยในน้ำซุปก๋วยจั๊บ บวกกับหมูกรอบและเครื่องใน #อร่อยห้ามพลาด','1481749319-omg-044.jpg'),
	(351,'ลิ้มเล่าซา ถนนทรงวาด','35-60 บาท','ทุกวัน : 18:00 - 02:00','ถนนทรงวาด (ร้านจะอยู่ด้านขวามือเข้าไปในตรอกเล็กๆ)','บะหมี่ลูกชิ้นปลาเจ้าเก่าแก่ที่ขายเฉพาะก๋วยเตี๋ยวลูกชิ้นปลาเท่านั้น ความพิเศษอยู่ที่ลูกชิ้นปลาที่ทางร้านทำเองสดๆกับมือ','1481749527-omg-055.jpg'),
	(361,'ข้าวต้มเป็ดตั้งหงีฮวด','40-60 บาท','ทุกวัน 11.00 - 22.00 น.','ถนนพิพากษา2 (ตรงข้ามวัดมงคลสมาคม)','ร้านข้าวต้มเป็ดเก่าแก่ที่อยู่คู่เยาวราชมากว่า 63 ปี ข้าวต้มเป็ดของร้านนี้เขาใช้เนื้อเป็ดส่วนอกต้มกับน้ำซุปสูตรพิเศษ ไม่มีกลิ่นคาว','1481749711-TangKyeeHuad_09.jpg'),
	(371,'ข้าวหมูแดงสีมรกต','50-100 บาท','ทุกวัน : 12:00 - 20:00','ซอยสุกร 1 (ตรอกสุกร 1 ก่อนถึงวัด)','ข้าวหมูแดงอร่อยๆ สูตรจีนโบราณเป็นร้านที่ไม่ควรพลาดเป็นอย่างยิ่ง เพราะนอกจากน้ำราดจะเป็นแบบดั้งเดิมมีรสเค็มๆหวานๆแล้ว ข้าวหมูแดงที่นี่ยังจานใหญ่มากๆด้วย','1481750020-omg-066.jpg'),
	(451,'ลอดช่องสิงคโปร์','20 บาทขึ้นไป','18.00-00.00 น.','เยาวราช','ร้านลอดช่องสิงคโปร์ร้านแรกของเมืองไทย ที่ขายมากว่า 60 ปี เดิมทีชื่อว่าร้านสิงคโปร์โภชนา เพราะในอดีตมีโรงหนังสิงคโปร์หรือโรงหนังเฉลิมบุรีอยุ่บนถนนเส้นนี้ แต่ต่อมาหลายคนมักเรียกสั้นๆ ว่า ร้านลอดช่องสิงคโปร์ จึงเปลี่ยนชื่อให้จำง่ายๆ ว่าร้านลอดช่องสิงคโปร์แทน ความอร่อยของร้านนี้คือแป้งหนึบๆ น้ำกะทิหอมหวาน เวลาทานตอนอากาศร้อนๆ จะชื่อนใจมากๆ ราคา 20 บาท/ถ้วย เท่านั้น','1482059443-1.JPG');

/*!40000 ALTER TABLE `yaowarat_review` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table yaowarat_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `yaowarat_user`;

CREATE TABLE `yaowarat_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `IMG` text,
  `statusID` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `yaowarat_user` WRITE;
/*!40000 ALTER TABLE `yaowarat_user` DISABLE KEYS */;

INSERT INTO `yaowarat_user` (`id`, `username`, `email`, `password`, `IMG`, `statusID`)
VALUES
	(1,'user_01','User233@gmail.com','1234',NULL,0),
	(2,'admin','admin@gmail.com','1234',NULL,1),
	(3,'Tamonwan','new@hotmail.com','eeee',NULL,2);

/*!40000 ALTER TABLE `yaowarat_user` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
